package com.nttdata.docto;

import java.util.Scanner;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

import com.nttdata.docto.dao.DoctorRepository;
import com.nttdata.docto.dao.SpecializationRepository;
import com.nttdata.docto.entity.Doctor;
import com.nttdata.docto.entity.Specialization;

@SpringBootApplication
@EnableJpaAuditing
public class DoctoApplication implements CommandLineRunner{
	/*@Autowired
    DataSource dataSource;
	
    @Autowired
    DoctorRepository doctorRepository;
    

    
	
    Scanner scan =new Scanner(System.in);*/
    @Autowired
     SpecializationRepository SpecRepository;
	public static void main(String[] args) {
		
		SpringApplication.run(DoctoApplication.class, args);
		System.out.println("Started");
		
	}
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		System.out.println(SpecRepository.findAllSpecsWithJpql());
	}

	

    /*public void run(String... args) throws Exception {
	   System.out.println(SpecRepository.findAllSpecsWithJpql());
        System.out.println("Our DataSource is = " + dataSource);
        Iterable<com.nttdata.docto.entity.Doctor> systemlist = doctorRepository.findAll();
        for(com.nttdata.docto.entity.Doctor systemmodel:systemlist){
            System.out.println("Here is a system: " + systemmodel.toString());
        }
   
    	
    	System.out.println("Enter the following details");
    	//System.out.println("Enter the id value ");
    	int id=5;
    	System.out.println("Enter the name");
    	String name=scan.next();
    	System.out.println("Enter the email");
    	String email=scan.next();
    	System.out.println("Enter the password");
    	String pass=scan.next();
    	System.out.println("Enter your age");
    	int age=scan.nextInt();
    	System.out.println("Choose from the following specs");
    	
    	Long spec=scan.nextLong();
    	Specialization specs=SpecRepository.findById(spec);
    	System.out.println("Enter your contact");
    	long contact=scan.nextLong();
    	System.out.println("Enter your area");
    	String area=scan.next();
    	System.out.println("Enter your location");
    	String location=scan.next();
    	Doctor doctor=new Doctor(id,name,email,pass,age,specs,contact,area,location);
    	doctorRepository.save(doctor);
    	System.out.println("successfully working");
    }*/

}



