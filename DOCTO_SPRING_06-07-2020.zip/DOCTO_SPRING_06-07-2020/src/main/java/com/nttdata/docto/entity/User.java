package com.nttdata.docto.entity;

import java.io.Serializable;
import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Size;


import org.springframework.format.annotation.DateTimeFormat;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


@Entity
@SequenceGenerator(name="useseq", initialValue=10, allocationSize=1)
public class User implements Serializable {
	

	@Email @NotEmpty
	private String email;
	
	@NotEmpty
	private String password;
	
	@NotEmpty
	private String country;

	@DateTimeFormat(pattern="yyyy-MM-dd")
    @Past @NotNull
	private Date dob;

	

	@Size(min=3, max=30)
	private String firstName;

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="useseq")
	private int userId;

	@Size(min=3, max=30)
	private String lastName;
	
	

	@NotEmpty
	private String sex;
	
	@NotEmpty
	private String address;
	
	@NotEmpty
	private String age;
	

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCountry() {
		return this.country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public Date getDob() {
		return this.dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	

	@Override
	public String toString() {
		return "User [email=" + email + ", password=" + password + ", country=" + country + ", dob=" + dob
				+ ", firstName=" + firstName + ", userId=" + userId + ", lastName=" + lastName + ", sex=" + sex
				+ ", address=" + address + ", age=" + age + "]";
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	
	public String getSex() {
		return this.sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	
	
}
