package com.nttdata.docto.dao;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.nttdata.docto.entity.User;

@Repository
@Transactional
public class UserRepository {
	
	@Autowired
	EntityManager em;
	
	public User save(User user){
		 if(user.getUserId()==0){
			 em.persist(user);
		 }
		 else{
			 em.merge(user);
		 }
		 return user;
	 }
}
